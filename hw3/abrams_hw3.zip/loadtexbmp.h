#ifndef LOADTEXBMP_H
#define LOADTEXBMP_H

unsigned int LoadTexBMP(const char * file);

#endif // LOADTEXBMP_H
