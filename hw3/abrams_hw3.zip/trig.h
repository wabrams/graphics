#include <math.h>
//  Cosine and Sine in degrees
#define Cos(x) (cos((x)*3.1415927/180))
#define Sin(x) (sin((x)*3.1415927/180))
#define Tan(x) (tan((x)*3.1415927/180))
